#!/bin/bash

# This is the script for printing 'Hello World' along with date and time

echo "Hello DevOps - Date: $(date)"
